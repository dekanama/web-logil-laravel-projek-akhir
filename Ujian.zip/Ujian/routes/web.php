<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('halaman');
})->middleware('auth');

use App\Http\Controllers\Anggota_pinjam;
Route::get('/anggota', [Anggota_pinjam::class, 'index'])->middleware('auth');
Route::get('/anggota/tambah', [Anggota_pinjam::class, 'add_new']);
Route::post('/anggota/save', [Anggota_pinjam::class, 'save']);
Route::get('/anggota/edit/{id}', [Anggota_pinjam::class, 'edit']);
Route::get('/anggota/delete/{id}', [Anggota_pinjam::class, 'delete']);

use App\Http\Controllers\Halaman_peminjam;
Route::get('/halaman', [Halaman_peminjam::class, 'index'])->middleware('auth');

/*
Route::get('/login', function () {
    return view('halaman.login');
});
*/
Route::get('login', [Halaman_peminjam::class, 'login'])->name('login')->middleware('guest');

use App\Http\Controllers\Login_peminjam;
Route::post('/login', [Login_peminjam::class, 'authenticate']);
Route::get('/logout', [Login_peminjam::class, 'logout']);