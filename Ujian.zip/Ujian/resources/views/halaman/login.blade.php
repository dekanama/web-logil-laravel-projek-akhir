<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Perpustakaan</title>
<style>
body {
    background-image: url(/css/latar.jpg);   
    background-size: cover;
    background-attachment: fixed;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 90vh;
    flex-direction: column;
}
*{
    font-family: sans-serif;
    box-sizing: border-box;
}
form {
    width: 500px;
    border: 2px solid #ccc;
    padding: 30px;
    border-radius: 35px;
}
h2 {
    text-align: center;
    margin-bottom: 40px;
}
input {
 display: block;
 border: 2px solid #ccc;
 width: 95%;
 padding: 10px;
 margin: 10px auto;
 border-radius: 5px;
}
label {
    color: #fff;
    font-size: 18px;
    padding: 10px;
    font-style: italic;
    font-family: 'Times New Roman', Times, serif;
}
button {
    float: right;
    background: #555;
    padding: 10px 15px;
    color: #fff;
    border-radius: 5px;
    margin-right: 10px;
    border: none;
}
button:hover{
    opacity: .7;
}
h1 {
    text-align: center;
    color: #fff;
    font-size: 40px;
    font-family: 'Times New Roman', Times, serif;
}
a {
    float: right;
    background: #555;
    padding: 10px 15px;
    color: #fff;
    border-radius: 5px;
    margin-right: 10px;
    border: none;
    text-decoration: none;
}
a:hover{
    opacity: .7;
}
legend{
    color: #fff;
    font-family: 'Times New Roman', Times, serif;
}
</style>
</head>
<body>
    <h1> Silahkan Login </h1>
    <form action="{{ url('/login') }}" method="post" accept-charset="utf-8">
    @csrf
    <fieldset>
        <legend>Login</legend>
        <p>
            <label for="username"> Username :</label>
            <input type="text" name="username" value="" />
        </p>
        <p>
            <label for="password"> Password :</label>
            <input type="password" name="password" value="" />
        </p>
        <input type="submit" name="btn_simpan" value="Login" />
    </fieldset>
</form>
</body>
</html>