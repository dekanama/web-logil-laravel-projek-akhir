<!DOCTYPE html>
<html>
    <head>
        <title>Tambah Anggota</title>
        <link rel="stylesheet" href="/css/style.css">
    </head>
<body>
    <h1 id="logo">Data Peminjam <span>Buku</span></h1>
    <nav>
        <ul>
            <li><a href="{{ url('logout') }}">Logout</a></li>
            <li><a href="{{ url('anggota/tambah' ) }}">Tambah anggota</a></li>
            <li><a href="{{ url('halaman') }}">Dashboard</a></li>
        </ul>
    </nav>
    <br>
    <br>
    <table border='2'>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>NIM</th>
            <th>Judul Buku</th>
            <th>Fakultas</th>
            <th>Tanggal Pinjam</th>
            <th>Batas Waktu</th>
            <th>Aksi</th>
        </tr>
    @php
        $no = 0;
    @endphp

    @foreach($query as $row)
        @php
            $no++;
        @endphp
        <tr>
            <td>{{ $no }}</td>
            <td>{{ $row['Nama'] }}</td>
            <td>{{ $row['NIM'] }}</td>
            <td>{{ $row['Judul_Buku'] }}</td>
            <td>{{ $optfakultas[$row['Fakultas']] }}</td>
            <td>{{ $row['Tanggal_Pinjam'] }}</td>
            <td>{{ $row['Batas_Waktu'] }}</td>
            <td>
                <a href={{ url('anggota/edit/'.$row['ID_Peminjam']) }}>Edit</a>
                <a href={{ url('anggota/delete/'.$row['ID_Peminjam']) }} 
                onclick="return confirm('Anda Yakin?')">Delete</a>
            </td>
        </tr>
@endforeach
</table>
</br>
<p> {{ $query->links('vendor.pagination.mypage') }} </p>
<font color="black" size="4.5">*Jika telat mengembalikan Buku akan dikenakan denda sebesar Rp.100.000.-</font>
</body>
</html>