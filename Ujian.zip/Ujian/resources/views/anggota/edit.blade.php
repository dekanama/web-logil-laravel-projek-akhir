<!DOCTYPE html>
<html>
<head>
    <title>Edit Peminjam</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <form action="{{ url('anggota/save') }}" method="post" accept-charset="utf-8">
        @csrf
        <input type="hidden" name="id" value="{{ $query->ID_Peminjam }}" />
        <input type="hidden" name="is_update" value="{{ $is_update }}" />

        <h2> Edit Peminjam </h2>
        <hr color="black">
        <br>

        <fieldset>
        <legend>Edit Peminjam</legend>
        <p>
            <label for="Nama">Nama : </label>
            <input type="text" name="Nama" value="{{ $query->Nama }}"/>
        </p>
        <p>
            <label for="NIM">NIM : </label>
            <input type="text" name="NIM" value="{{ $query->NIM }}"/>
        </p>
        <p>
            <label for="Judul_Buku">Judul Buku : </label>
            <input type="text" name="Judul_Buku" value="{{ $query->Judul_Buku }}"/>
        </p>
        <p>
            <label for="Fakultas">Fakultas : </label>
            <select name="Fakultas">
            @foreach ($optfakultas as $key => $value)
                @if ($query->Fakultas == $key)
                <option value="{{ $key }}" selected>{{ $value }}</option>
                @else
                <option value="{{ $key }}">{{ $value }}</option>
                @endif
            @endforeach
        </select>
        </p>
        <p>
            <label for="Tanggal_Pinjam">Tanggal Pinjam : </label>
            <input type="date" name="Tanggal_Pinjam" value="" />
        </p>
        <p>
            <label for="Batas_Waktu">Batas Waktu : </label>
            <input type="date" name="Batas_Waktu" value="" />
        </p>
        </fieldset>
        <br/><br/><input type="submit" same="btn_simpan" value="Simpan" />
</form>
</body>
</html>