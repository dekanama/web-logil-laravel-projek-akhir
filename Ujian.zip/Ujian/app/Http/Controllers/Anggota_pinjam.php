<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Anggota_P;

class Anggota_pinjam extends Controller
{
    var $data;

    public function __construct()
    {
        $this->data['opt_fakultas'] = [
            '' => '-Pilih salah satu -',
            'teknik informatika' => 'Teknik Informatika',
            'sistem informasi' => 'Sistem Informasi',
            'ilmu komunikasi' => 'Ilmu Komunikasi',
            'hukum' => 'Hukum',
            'sosiologi' => 'Sosiologi',
            'ekonomi' => 'Ekonomi',
            'manajemen' => 'Manajemen'
        ];
    }

    public function index(Anggota_P $anggota)
    {
        $data = [
            //'query' => $anggota->get_records(),
            'query' => $anggota->paginate(5),
            'optfakultas' => $this->data['opt_fakultas']
        ];
        return view('anggota.tampil', $data);
    }

    public function add_new()
    {
        $data = [
            'is_update' => 0,
            'optfakultas' => $this->data['opt_fakultas']
        ];
        return view('anggota.tambah', $data);
    }

    public function save(Anggota_P $anggota, Request $request)
    {
        $data['Nama']     = $request->input('Nama');
        $data['NIM']         = $request->input('NIM');
        $data['Judul_Buku']      = $request->input('Judul_Buku');
        $data['Fakultas']      = $request->input('Fakultas');
        $data['Tanggal_Pinjam']      = $request->input('Tanggal_Pinjam');
        $data['Batas_waktu']      = $request->input('Batas_Waktu');
        $is_update = $request->input('is_update');

        if($is_update==0)
        {
            if($anggota->insert_record($data));
                return redirect('anggota');
        }
        else
        {
            $id=$request->input('id');
            if($anggota->update_by_id($data,$id));
                return redirect('anggota');
        }
    }

    public function edit($id, Anggota_P $anggota)
    {
        $data = [
            'query' => $anggota->get_records($id)->first(),
            'is_update' => 1,
            'optfakultas' => $this->data['opt_fakultas']
        ];
        return view('anggota.edit', $data);
    }

    public function delete($id, Anggota_P $anggota)
    {
        if($anggota->delete_by_id($id))
            return redirect('anggota');
    }    
}