<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Halaman_peminjam extends Controller
{
    public function index()
    {
        return view('halaman.main');
    }

    public function login()
    {
        return view('halaman.login');
    }
}
