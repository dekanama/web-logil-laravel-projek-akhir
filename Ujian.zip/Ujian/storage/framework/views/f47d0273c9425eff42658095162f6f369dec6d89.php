<?php if($paginator->hasPages()): ?>
<p>
            
            <?php if($paginator->onFirstPage()): ?>
                <span><?php echo app('translator')->get('pagination.previous'); ?></span>
            <?php else: ?>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>"><?php echo app('translator')->get('pagination.previous'); ?></a>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <span><?php echo e($element); ?></span>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <span><?php echo e($page); ?></span>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>"><?php echo app('translator')->get('pagination.next'); ?></a>
            <?php else: ?>
                <span><?php echo app('translator')->get('pagination.next'); ?></span>
            <?php endif; ?>
</p>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\Ujian\resources\views/vendor/pagination/mypage.blade.php ENDPATH**/ ?>