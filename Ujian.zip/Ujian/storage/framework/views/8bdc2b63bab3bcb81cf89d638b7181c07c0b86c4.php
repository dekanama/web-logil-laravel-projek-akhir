<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Perpustakaan</title>

    <link rel="stylesheet" href="/css/style.css">

</head>
<body>
    <h2>Aplikasi Peminjaman Buku</h2>
    <hr color="black">
    <nav>
        <ul>
        <li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
        <li><a href="<?php echo e(url('anggota')); ?>">Daftar Pinjam Buku</a></li>
        </ul>
    </nav>
    <br>
    <br>
    <marquee style="font-family:times new roman; font-size:20px; color:#000000;" scrollamount="10">Kuasailah semua buku, tapi jangan biarkan buku menguasai Anda.
    Membacalah untuk hidup, bukan hidup untuk membaca :)</marquee>
    <center><br><img src="css/USM.png" height="350" width="350"></center>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\Ujian\resources\views/halaman/main.blade.php ENDPATH**/ ?>