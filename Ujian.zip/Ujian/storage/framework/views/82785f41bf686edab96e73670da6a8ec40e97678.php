<!DOCTYPE html>
<html>
    <head>
        <title>Tambah Anggota</title>
        <link rel="stylesheet" href="/css/style.css">
    </head>
<body>
    <h1 id="logo">Data Peminjam <span>Buku</span></h1>
    <nav>
        <ul>
            <li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
            <li><a href="<?php echo e(url('anggota/tambah' )); ?>">Tambah anggota</a></li>
            <li><a href="<?php echo e(url('halaman')); ?>">Dashboard</a></li>
        </ul>
    </nav>
    <br>
    <br>
    <table border='2'>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>NIM</th>
            <th>Judul Buku</th>
            <th>Fakultas</th>
            <th>Tanggal Pinjam</th>
            <th>Batas Waktu</th>
            <th>Aksi</th>
        </tr>
    <?php
        $no = 0;
    ?>

    <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $no++;
        ?>
        <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($row['Nama']); ?></td>
            <td><?php echo e($row['NIM']); ?></td>
            <td><?php echo e($row['Judul_Buku']); ?></td>
            <td><?php echo e($optfakultas[$row['Fakultas']]); ?></td>
            <td><?php echo e($row['Tanggal_Pinjam']); ?></td>
            <td><?php echo e($row['Batas_Waktu']); ?></td>
            <td>
                <a href=<?php echo e(url('anggota/edit/'.$row['ID_Peminjam'])); ?>>Edit</a>
                <a href=<?php echo e(url('anggota/delete/'.$row['ID_Peminjam'])); ?> 
                onclick="return confirm('Anda Yakin?')">Delete</a>
            </td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</br>
<p> <?php echo e($query->links('vendor.pagination.mypage')); ?> </p>
<font color="black" size="4.5">*Jika telat mengembalikan Buku akan dikenakan denda sebesar Rp.100.000.-</font>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\Ujian\resources\views/anggota/tampil.blade.php ENDPATH**/ ?>