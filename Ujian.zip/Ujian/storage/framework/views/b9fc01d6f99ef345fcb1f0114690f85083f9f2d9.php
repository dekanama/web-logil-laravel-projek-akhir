<!DOCTYPE html>
<html>
<head>
    <title>Edit Peminjam</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <form action="<?php echo e(url('anggota/save')); ?>" method="post" accept-charset="utf-8">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($query->ID_Peminjam); ?>" />
        <input type="hidden" name="is_update" value="<?php echo e($is_update); ?>" />

        <h2> Edit Peminjam </h2>
        <hr color="black">
        <br>

        <fieldset>
        <legend>Edit Peminjam</legend>
        <p>
            <label for="Nama">Nama : </label>
            <input type="text" name="Nama" value="<?php echo e($query->Nama); ?>"/>
        </p>
        <p>
            <label for="NIM">NIM : </label>
            <input type="text" name="NIM" value="<?php echo e($query->NIM); ?>"/>
        </p>
        <p>
            <label for="Judul_Buku">Judul Buku : </label>
            <input type="text" name="Judul_Buku" value="<?php echo e($query->Judul_Buku); ?>"/>
        </p>
        <p>
            <label for="Fakultas">Fakultas : </label>
            <select name="Fakultas">
            <?php $__currentLoopData = $optfakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($query->Fakultas == $key): ?>
                <option value="<?php echo e($key); ?>" selected><?php echo e($value); ?></option>
                <?php else: ?>
                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </p>
        <p>
            <label for="Tanggal_Pinjam">Tanggal Pinjam : </label>
            <input type="date" name="Tanggal_Pinjam" value="" />
        </p>
        <p>
            <label for="Batas_Waktu">Batas Waktu : </label>
            <input type="date" name="Batas_Waktu" value="" />
        </p>
        </fieldset>
        <br/><br/><input type="submit" same="btn_simpan" value="Simpan" />
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\Ujian\resources\views/anggota/edit.blade.php ENDPATH**/ ?>